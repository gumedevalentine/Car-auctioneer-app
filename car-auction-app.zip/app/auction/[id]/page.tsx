"use client"

import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { CountdownTimer } from "@/components/auction/countdown-timer"
import { BiddingPanel } from "@/components/auction/bidding-panel"
import { BidHistory } from "@/components/auction/bid-history"
import { CarGallery } from "@/components/auction/car-gallery"
import { LiveActivity } from "@/components/auction/live-activity"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Car, MapPin, Gauge, Heart, Share2 } from "lucide-react"

// Mock auction data
const mockAuction = {
  id: "1",
  car: {
    make: "Porsche",
    model: "911 GT3",
    year: 2022,
    mileage: 2500,
    location: "Beverly Hills, CA",
    vin: "WP0AC2A99NS171234",
    engine: "4.0L Naturally Aspirated Flat-6",
    transmission: "7-Speed PDK",
    drivetrain: "RWD",
    fuelType: "Premium Gasoline",
    images: ["/placeholder-zev2n.png", "/yellow-ferrari-f8-tributo.png", "/2020-mclaren-720s-blue.png"],
  },
  currentBid: 185000,
  reservePrice: 200000,
  bidIncrement: 2500,
  endTime: "2025-01-20T18:00:00Z",
  isReserveMet: false,
  totalBids: 12,
  watchers: 47,
}

const mockBids = [
  {
    id: "1",
    amount: 185000,
    bidder: { id: "user1", name: "John D." },
    timestamp: "2025-01-15T14:30:00Z",
    isWinning: true,
  },
  {
    id: "2",
    amount: 180000,
    bidder: { id: "user2", name: "Sarah M." },
    timestamp: "2025-01-15T14:25:00Z",
  },
  {
    id: "3",
    amount: 175000,
    bidder: { id: "current", name: "You", isCurrentUser: true },
    timestamp: "2025-01-15T14:20:00Z",
  },
]

export default function AuctionPage({ params }: { params: { id: string } }) {
  const [currentBid, setCurrentBid] = useState(mockAuction.currentBid)
  const [bids, setBids] = useState(mockBids)
  const [userMaxBid, setUserMaxBid] = useState(175000)

  const handlePlaceBid = (amount: number) => {
    const newBid = {
      id: Date.now().toString(),
      amount,
      bidder: { id: "current", name: "You", isCurrentUser: true },
      timestamp: new Date().toISOString(),
      isWinning: true,
    }

    // Update bids
    const updatedBids = [newBid, ...bids.map((bid) => ({ ...bid, isWinning: false }))]
    setBids(updatedBids)
    setCurrentBid(amount)
    setUserMaxBid(amount)
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-8">
        <div className="container mx-auto px-4 max-w-7xl">
          {/* Header Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-serif font-bold">
                  {mockAuction.car.year} {mockAuction.car.make} {mockAuction.car.model}
                </h1>
                <div className="flex items-center space-x-4 mt-2 text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <MapPin className="h-4 w-4" />
                    <span>{mockAuction.car.location}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Gauge className="h-4 w-4" />
                    <span>{mockAuction.car.mileage.toLocaleString()} miles</span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">
                  <Heart className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-green-600 border-green-200">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse" />
                Live Auction
              </Badge>
              <span className="text-sm text-muted-foreground">{mockAuction.totalBids} bids</span>
              <span className="text-sm text-muted-foreground">{mockAuction.watchers} watching</span>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Car Details */}
            <div className="lg:col-span-2 space-y-6">
              <CarGallery
                images={mockAuction.car.images}
                carName={`${mockAuction.car.year} ${mockAuction.car.make} ${mockAuction.car.model}`}
              />

              {/* Car Specifications */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Car className="h-5 w-5 text-primary" />
                    <span>Vehicle Specifications</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Year</span>
                        <span className="font-medium">{mockAuction.car.year}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Mileage</span>
                        <span className="font-medium">{mockAuction.car.mileage.toLocaleString()} miles</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Engine</span>
                        <span className="font-medium">{mockAuction.car.engine}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">VIN</span>
                        <span className="font-medium font-mono text-sm">{mockAuction.car.vin}</span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Transmission</span>
                        <span className="font-medium">{mockAuction.car.transmission}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Drivetrain</span>
                        <span className="font-medium">{mockAuction.car.drivetrain}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Fuel Type</span>
                        <span className="font-medium">{mockAuction.car.fuelType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Location</span>
                        <span className="font-medium">{mockAuction.car.location}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Bid History */}
              <BidHistory bids={bids} currentUserId="current" />
            </div>

            {/* Right Column - Bidding Panel */}
            <div className="space-y-6">
              <CountdownTimer endTime={mockAuction.endTime} />

              <BiddingPanel
                currentBid={currentBid}
                reservePrice={mockAuction.reservePrice}
                bidIncrement={mockAuction.bidIncrement}
                isReserveMet={mockAuction.isReserveMet}
                onPlaceBid={handlePlaceBid}
                userMaxBid={userMaxBid}
              />

              <LiveActivity auctionId={params.id} />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
