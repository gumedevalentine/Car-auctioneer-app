import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { CarManagement } from "@/components/admin/car-management"

export default function AdminCarsPage() {
  return (
    <div className="flex min-h-screen bg-background">
      <AdminSidebar />
      <main className="flex-1 lg:ml-64 p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div>
            <h1 className="text-3xl font-serif font-bold">Car Management</h1>
            <p className="text-muted-foreground">Manage auction vehicles and their details</p>
          </div>
          <CarManagement />
        </div>
      </main>
    </div>
  )
}
