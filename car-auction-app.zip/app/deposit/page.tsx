"use client"

import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { BankDetails } from "@/components/deposit/bank-details"
import { DepositForm } from "@/components/deposit/deposit-form"
import { DepositStatus } from "@/components/deposit/deposit-status"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, Upload, History, Info } from "lucide-react"

// Mock data for deposit history
const mockDeposits = [
  {
    id: "1",
    amount: 5000,
    status: "approved" as const,
    submittedAt: "2025-01-10T10:30:00Z",
    reviewedAt: "2025-01-10T14:20:00Z",
    carId: "1",
    carName: "2022 Porsche 911 GT3",
    referenceNumber: "DEPOSIT-USER123-CAR001",
    notes: "Wire transfer completed successfully",
  },
  {
    id: "2",
    amount: 5000,
    status: "pending" as const,
    submittedAt: "2025-01-12T09:15:00Z",
    carId: "2",
    carName: "2021 Ferrari F8 Tributo",
    referenceNumber: "DEPOSIT-USER123-CAR002",
  },
]

export default function DepositPage() {
  const [activeTab, setActiveTab] = useState("submit")

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-serif font-bold mb-2">Deposit Management</h1>
            <p className="text-muted-foreground">
              Secure your auction participation with a refundable deposit via bank transfer
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="info" className="flex items-center space-x-2">
                <Info className="h-4 w-4" />
                <span className="hidden sm:inline">Info</span>
              </TabsTrigger>
              <TabsTrigger value="bank" className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4" />
                <span className="hidden sm:inline">Bank Details</span>
              </TabsTrigger>
              <TabsTrigger value="submit" className="flex items-center space-x-2">
                <Upload className="h-4 w-4" />
                <span className="hidden sm:inline">Submit</span>
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center space-x-2">
                <History className="h-4 w-4" />
                <span className="hidden sm:inline">History</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="info">
              <Card>
                <CardHeader>
                  <CardTitle>How Deposits Work</CardTitle>
                  <CardDescription>Understanding our secure deposit system for auction participation</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold">Deposit Requirements</h3>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li>• $5,000 refundable deposit per vehicle</li>
                        <li>• Required before bidding begins</li>
                        <li>• Fully refundable if you don't win</li>
                        <li>• Applied to purchase if you win</li>
                      </ul>
                    </div>
                    <div className="space-y-4">
                      <h3 className="font-semibold">Process Timeline</h3>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li>• Submit deposit: Instant</li>
                        <li>• Review & approval: 24-48 hours</li>
                        <li>• Bidding access: After approval</li>
                        <li>• Refund processing: 3-5 business days</li>
                      </ul>
                    </div>
                  </div>
                  <div className="p-4 bg-accent/5 border border-accent/20 rounded-md">
                    <h4 className="font-medium text-accent-foreground mb-2">Security & Trust</h4>
                    <p className="text-sm text-muted-foreground">
                      All deposits are held in a secure escrow account and are fully insured. We use bank-grade security
                      to protect your funds and personal information.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="bank">
              <BankDetails />
            </TabsContent>

            <TabsContent value="submit">
              <DepositForm carId="example-car" requiredAmount={5000} />
            </TabsContent>

            <TabsContent value="history">
              <DepositStatus deposits={mockDeposits} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}
