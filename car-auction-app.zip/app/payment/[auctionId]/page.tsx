"use client"

import { Button } from "@/components/ui/button"

import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PaymentSummary } from "@/components/payment/payment-summary"
import { PaymentMethods } from "@/components/payment/payment-methods"
import { PaymentConfirmation } from "@/components/payment/payment-confirmation"

// Mock auction data
const mockAuction = {
  id: "1",
  car: {
    make: "Porsche",
    model: "911 GT3",
    year: 2022,
    images: ["/placeholder-zev2n.png"],
  },
  winningBid: 185000,
  deposit: 5000,
  fees: {
    buyersPremium: 18500, // 10% of winning bid
    documentation: 500,
    transport: 1200,
  },
}

export default function PaymentPage({ params }: { params: { auctionId: string } }) {
  const [paymentStep, setPaymentStep] = useState<"summary" | "payment" | "confirmation">("summary")
  const [paymentResult, setPaymentResult] = useState<any>(null)

  const totalDue =
    mockAuction.winningBid +
    mockAuction.fees.buyersPremium +
    mockAuction.fees.documentation +
    (mockAuction.fees.transport || 0) -
    mockAuction.deposit

  const handlePaymentSubmit = (method: string, details: any) => {
    console.log("[v0] Payment submitted:", method, details)

    // Simulate payment processing
    setTimeout(() => {
      const payment = {
        id: `PAY-${Date.now()}`,
        method,
        amount: totalDue,
        status: method === "wire" ? "pending" : ("completed" as const),
        completedAt: method !== "wire" ? new Date().toISOString() : undefined,
        car: mockAuction.car,
        pickupLocation: "Elite Auto Auctions, Beverly Hills, CA",
        pickupDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
      }
      setPaymentResult(payment)
      setPaymentStep("confirmation")
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-serif font-bold mb-2">Complete Your Purchase</h1>
            <p className="text-muted-foreground">Finalize payment for your winning auction bid</p>
          </div>

          {paymentStep === "summary" && (
            <div className="space-y-6">
              <PaymentSummary auction={mockAuction} />
              <div className="text-center">
                <Button onClick={() => setPaymentStep("payment")} size="lg" className="px-8">
                  Proceed to Payment
                </Button>
              </div>
            </div>
          )}

          {paymentStep === "payment" && <PaymentMethods totalAmount={totalDue} onPaymentSubmit={handlePaymentSubmit} />}

          {paymentStep === "confirmation" && paymentResult && <PaymentConfirmation payment={paymentResult} />}
        </div>
      </main>
      <Footer />
    </div>
  )
}
